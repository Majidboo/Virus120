function Black() {
  document.body.style.background = " black";
  
}

function White(){
  document.body.style.background = "white";
}